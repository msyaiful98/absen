package com.example.fakegps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast

class MockLocationService : Service() {

    companion object {
        @Volatile
        var running = false

        private const val CHANNEL_ID = "fake_gps_channel"
        private const val NOTIF_ID = 1
        private const val INTERVAL_MS = 1000L
    }

    private lateinit var lm: LocationManager
    private val handler = Handler(Looper.getMainLooper())
    private var lat = 0.0
    private var lon = 0.0
    private var providerAdded = false

    private val injector = object : Runnable {
        override fun run() {
            if (!injectLocation()) {
                stopSelf()
                return
            }
            handler.postDelayed(this, INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LocationManager::class.java)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Jangan jalan dua kali kalau sudah aktif.
        if (running) return START_NOT_STICKY

        try {
            startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } catch (e: Exception) {
            fail("Gagal menjalankan service: ${e.message}")
            return START_NOT_STICKY
        }

        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val savedLat = prefs.getString(MainActivity.KEY_LAT, null)?.toDoubleOrNull()
        val savedLon = prefs.getString(MainActivity.KEY_LON, null)?.toDoubleOrNull()
        if (savedLat == null || savedLon == null) {
            fail("Belum ada lokasi tersimpan.")
            return START_NOT_STICKY
        }
        lat = savedLat
        lon = savedLon

        if (!startMocking()) {
            fail("Aplikasi belum dipilih sebagai Mock location app di Opsi Pengembang.")
            return START_NOT_STICKY
        }

        running = true
        handler.post(injector)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(injector)
        stopMocking()
        running = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ----------------------------------------------------------- Mock GPS

    private fun startMocking(): Boolean {
        return try {
            // Bersihkan sisa provider lama (kalau ada).
            try {
                lm.removeTestProvider(LocationManager.GPS_PROVIDER)
            } catch (e: Exception) {
                // abaikan
            }
            lm.addTestProvider(
                LocationManager.GPS_PROVIDER,
                false, false, false, false, true, true, true,
                Criteria.POWER_LOW, Criteria.ACCURACY_FINE
            )
            providerAdded = true
            lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true)
            true
        } catch (e: SecurityException) {
            false
        } catch (e: Exception) {
            false
        }
    }

    private fun injectLocation(): Boolean {
        return try {
            val loc = Location(LocationManager.GPS_PROVIDER)
            loc.latitude = lat
            loc.longitude = lon
            loc.altitude = 0.0
            loc.accuracy = 3.0f
            loc.speed = 0.0f
            loc.bearing = 0.0f
            loc.time = System.currentTimeMillis()
            loc.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            lm.setTestProviderLocation(LocationManager.GPS_PROVIDER, loc)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun stopMocking() {
        if (!providerAdded) return
        try {
            lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false)
        } catch (e: Exception) {
            // abaikan
        }
        try {
            lm.removeTestProvider(LocationManager.GPS_PROVIDER)
        } catch (e: Exception) {
            // abaikan
        }
        providerAdded = false
    }

    private fun fail(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        stopSelf()
    }

    // ------------------------------------------------------- Notifikasi

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Fake GPS", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Fake GPS Active")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }
}
