package com.example.fakegps

import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class LockTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile(MockLocationService.running)
    }

    override fun onClick() {
        super.onClick()

        if (MockLocationService.running) {
            stopService(Intent(this, MockLocationService::class.java))
            updateTile(false)
            return
        }

        // Belum siap (izin / koordinat / mock app) -> buka aplikasi untuk menyiapkan.
        if (!canStart()) {
            openApp()
            return
        }

        try {
            startForegroundService(Intent(this, MockLocationService::class.java))
            updateTile(true)
        } catch (e: Exception) {
            // Android membatasi start dari latar belakang -> buka aplikasi sebagai cadangan.
            openApp()
        }
    }

    private fun canStart(): Boolean {
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return false

        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        if (prefs.getString(MainActivity.KEY_LAT, null)?.toDoubleOrNull() == null) return false
        if (prefs.getString(MainActivity.KEY_LON, null)?.toDoubleOrNull() == null) return false

        return MockLocationService.isMockAllowed(this)
    }

    private fun updateTile(active: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Lock"
        tile.subtitle = if (active) "Aktif" else "Mati"
        tile.icon = Icon.createWithResource(this, R.drawable.ic_lock_small)
        tile.updateTile()
    }

    @Suppress("DEPRECATION")
    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            startActivityAndCollapse(intent)
        }
    }
}
