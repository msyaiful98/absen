package com.example.fakegps

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        const val PREFS = "fakegps_prefs"
        const val KEY_LAT = "lat"
        const val KEY_LON = "lon"
        private const val REQ_PERM = 100
    }

    private lateinit var switchMock: Switch
    private lateinit var btnCapture: Button
    private lateinit var tvCoords: TextView
    private lateinit var tvStatus: TextView
    private lateinit var prefs: SharedPreferences

    private var ignoreSwitch = false
    private var afterPermission: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        switchMock = findViewById(R.id.switchMock)
        btnCapture = findViewById(R.id.btnCapture)
        tvCoords = findViewById(R.id.tvCoords)
        tvStatus = findViewById(R.id.tvStatus)

        btnCapture.setOnClickListener {
            requestLocationThen { captureLocation() }
        }

        switchMock.setOnCheckedChangeListener { _, isChecked ->
            if (ignoreSwitch) return@setOnCheckedChangeListener
            if (isChecked) tryTurnOn() else turnOff()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi(MockLocationService.running)
    }

    // ---------------------------------------------------------------- UI

    private fun refreshUi(active: Boolean) {
        setSwitch(active)
        tvStatus.text = if (active) "Status: AKTIF" else "Status: MATI"

        val lat = prefs.getString(KEY_LAT, null)
        val lon = prefs.getString(KEY_LON, null)
        tvCoords.text = if (lat != null && lon != null) {
            "Lokasi tersimpan:\nLatitude: $lat\nLongitude: $lon"
        } else {
            "Belum ada lokasi tersimpan"
        }
    }

    private fun setSwitch(checked: Boolean) {
        ignoreSwitch = true
        switchMock.isChecked = checked
        ignoreSwitch = false
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------- Permissions

    private fun hasLocationPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocationThen(action: () -> Unit) {
        if (hasLocationPermission()) {
            action()
            return
        }
        afterPermission = action
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissions(perms.toTypedArray(), REQ_PERM)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERM) return

        val action = afterPermission
        afterPermission = null
        if (hasLocationPermission()) {
            action?.invoke()
        } else {
            toast("Izin lokasi diperlukan. Pilih lokasi \"Presisi\" (Precise).")
            setSwitch(false)
        }
    }

    // ----------------------------------------------------- Capture lokasi

    private fun captureLocation() {
        if (MockLocationService.running) {
            toast("Matikan Fake GPS dulu supaya lokasi asli bisa dibaca.")
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        if (!lm.isLocationEnabled) {
            toast("Aktifkan layanan Lokasi di pengaturan HP.")
            return
        }

        toast("Mengambil lokasi...")
        requestFix(lm, LocationManager.GPS_PROVIDER) { gps ->
            if (gps != null) {
                saveLocation(gps)
            } else {
                requestFix(lm, LocationManager.NETWORK_PROVIDER) { net ->
                    val loc = net ?: lastKnown(lm)
                    if (loc != null) saveLocation(loc)
                    else toast("Gagal mendapat lokasi. Coba di tempat terbuka.")
                }
            }
        }
    }

    private fun requestFix(lm: LocationManager, provider: String, cb: (Location?) -> Unit) {
        if (!lm.isProviderEnabled(provider)) {
            cb(null)
            return
        }
        try {
            lm.getCurrentLocation(provider, null, mainExecutor) { loc -> cb(loc) }
        } catch (e: SecurityException) {
            cb(null)
        }
    }

    private fun lastKnown(lm: LocationManager): Location? {
        return try {
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        } catch (e: SecurityException) {
            null
        }
    }

    private fun saveLocation(loc: Location) {
        prefs.edit()
            .putString(KEY_LAT, loc.latitude.toString())
            .putString(KEY_LON, loc.longitude.toString())
            .apply()
        refreshUi(MockLocationService.running)
        toast("Lokasi disimpan.")
    }

    // --------------------------------------------------- Switch ON / OFF

    private fun tryTurnOn() {
        if (prefs.getString(KEY_LAT, null) == null || prefs.getString(KEY_LON, null) == null) {
            toast("Tekan \"Capture Current Location\" dulu.")
            setSwitch(false)
            return
        }

        requestLocationThen {
            if (!isMockLocationAllowed()) {
                setSwitch(false)
                showMockSettingDialog()
            } else {
                startForegroundService(Intent(this, MockLocationService::class.java))
                refreshUi(true)
                // Sinkronkan lagi kalau service ternyata gagal start.
                handler.postDelayed({ refreshUi(MockLocationService.running) }, 1500)
            }
        }
    }

    private fun turnOff() {
        stopService(Intent(this, MockLocationService::class.java))
        refreshUi(false)
    }

    // ------------------------------------------------ Cek Mock Location App

    /** True kalau app ini sudah dipilih sebagai "Mock location app" di Opsi Pengembang. */
    private fun isMockLocationAllowed(): Boolean {
        val lm = getSystemService(LocationManager::class.java)
        return try {
            lm.addTestProvider(
                LocationManager.GPS_PROVIDER,
                false, false, false, false, true, true, true,
                Criteria.POWER_LOW, Criteria.ACCURACY_FINE
            )
            lm.removeTestProvider(LocationManager.GPS_PROVIDER)
            true
        } catch (e: SecurityException) {
            false
        } catch (e: IllegalArgumentException) {
            true // provider sudah ada = izin sudah ada
        } catch (e: Exception) {
            false
        }
    }

    private fun showMockSettingDialog() {
        AlertDialog.Builder(this)
            .setTitle("Mock Location belum diaktifkan")
            .setMessage(
                "Aplikasi ini belum dipilih sebagai \"Mock location app\".\n\n" +
                "Buka Opsi Pengembang > Pilih aplikasi lokasi palsu (Select mock location app) " +
                "> pilih Fake GPS.\n\n" +
                "Kalau Opsi Pengembang belum muncul: Pengaturan > Tentang ponsel > " +
                "ketuk Nomor build 7 kali."
            )
            .setPositiveButton("Buka Pengaturan") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                } catch (e: ActivityNotFoundException) {
                    toast("Opsi Pengembang belum aktif di HP ini.")
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
