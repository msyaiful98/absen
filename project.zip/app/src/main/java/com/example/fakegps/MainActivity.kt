package com.example.fakegps

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.StatusBarManager
import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        const val PREFS = "fakegps_prefs"
        const val KEY_LAT = "lat"
        const val KEY_LON = "lon"
        private const val REQ_PERM = 100
    }

    private lateinit var switchMock: Switch
    private lateinit var btnCapture: Button
    private lateinit var btnPaste: Button
    private lateinit var btnSaveManual: Button
    private lateinit var btnAddTile: Button
    private lateinit var tvCoords: TextView
    private lateinit var tvStatus: TextView
    private lateinit var etCoord: EditText
    private lateinit var prefs: SharedPreferences

    private var ignoreSwitch = false
    private var afterPermission: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        switchMock = findViewById(R.id.switchMock)
        btnCapture = findViewById(R.id.btnCapture)
        btnPaste = findViewById(R.id.btnPaste)
        btnSaveManual = findViewById(R.id.btnSaveManual)
        btnAddTile = findViewById(R.id.btnAddTile)
        tvCoords = findViewById(R.id.tvCoords)
        tvStatus = findViewById(R.id.tvStatus)
        etCoord = findViewById(R.id.etCoord)

        fillInputFromPrefs()

        btnCapture.setOnClickListener {
            requestLocationThen { captureLocation() }
        }
        btnPaste.setOnClickListener { pasteFromClipboard() }
        btnSaveManual.setOnClickListener { saveManualLocation() }
        btnAddTile.setOnClickListener { addTile() }

        switchMock.setOnCheckedChangeListener { _, isChecked ->
            if (ignoreSwitch) return@setOnCheckedChangeListener
            if (isChecked) tryTurnOn() else turnOff()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi(MockLocationService.running)
    }

    // ---------------------------------------------------------------- UI

    private fun refreshUi(active: Boolean) {
        setSwitch(active)
        tvStatus.text = if (active) "Status: AKTIF" else "Status: MATI"

        val lat = prefs.getString(KEY_LAT, null)
        val lon = prefs.getString(KEY_LON, null)
        tvCoords.text = if (lat != null && lon != null) {
            "Lokasi tersimpan:\nLatitude: $lat\nLongitude: $lon"
        } else {
            "Belum ada lokasi tersimpan"
        }
    }

    private fun setSwitch(checked: Boolean) {
        ignoreSwitch = true
        switchMock.isChecked = checked
        ignoreSwitch = false
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------- Permissions

    private fun hasLocationPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocationThen(action: () -> Unit) {
        if (hasLocationPermission()) {
            action()
            return
        }
        afterPermission = action
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissions(perms.toTypedArray(), REQ_PERM)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERM) return

        val action = afterPermission
        afterPermission = null
        if (hasLocationPermission()) {
            action?.invoke()
        } else {
            toast("Izin lokasi diperlukan. Pilih lokasi \"Presisi\" (Precise).")
            setSwitch(false)
        }
    }

    // ----------------------------------------------------- Ambil lokasi saat ini

    private fun captureLocation() {
        if (MockLocationService.running) {
            toast("Matikan Lock GPS dulu supaya lokasi asli bisa dibaca.")
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        if (!lm.isLocationEnabled) {
            toast("Aktifkan layanan Lokasi di pengaturan HP.")
            return
        }

        toast("Mengambil lokasi...")
        requestFix(lm, LocationManager.GPS_PROVIDER) { gps ->
            if (gps != null) {
                saveLocation(gps)
            } else {
                requestFix(lm, LocationManager.NETWORK_PROVIDER) { net ->
                    val loc = net ?: lastKnown(lm)
                    if (loc != null) saveLocation(loc)
                    else toast("Gagal mendapat lokasi. Coba di tempat terbuka.")
                }
            }
        }
    }

    private fun requestFix(lm: LocationManager, provider: String, cb: (Location?) -> Unit) {
        if (!lm.isProviderEnabled(provider)) {
            cb(null)
            return
        }
        try {
            lm.getCurrentLocation(provider, null, mainExecutor) { loc -> cb(loc) }
        } catch (e: SecurityException) {
            cb(null)
        }
    }

    private fun lastKnown(lm: LocationManager): Location? {
        return try {
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        } catch (e: SecurityException) {
            null
        }
    }

    private fun saveLocation(loc: Location) {
        prefs.edit()
            .putString(KEY_LAT, loc.latitude.toString())
            .putString(KEY_LON, loc.longitude.toString())
            .apply()
        fillInputFromPrefs()
        refreshUi(MockLocationService.running)
        toast("Lokasi disimpan.")
    }

    // ------------------------------------------------- Input koordinat manual

    private fun fillInputFromPrefs() {
        val lat = prefs.getString(KEY_LAT, null)
        val lon = prefs.getString(KEY_LON, null)
        etCoord.setText(if (lat != null && lon != null) "$lat,$lon" else "")
    }

    /**
     * Terima format dari Google Maps: "-7.768287,111.526573"
     * (juga "-7.768287, 111.526573" atau dipisah spasi / titik koma).
     */
    private fun parseCoordinates(raw: String): Pair<Double, Double>? {
        val cleaned = raw.replace(Regex("[()°]"), " ")
        val parts = cleaned.trim().split(Regex("[,;\\s]+")).filter { it.isNotEmpty() }
        if (parts.size != 2) return null
        val lat = parts[0].toDoubleOrNull() ?: return null
        val lon = parts[1].toDoubleOrNull() ?: return null
        return Pair(lat, lon)
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(ClipboardManager::class.java)
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this)?.toString()
        } else null

        if (text.isNullOrBlank()) {
            toast("Clipboard kosong. Salin koordinat dari Google Maps dulu.")
            return
        }
        etCoord.setText(text.trim())
        saveManualLocation()
    }

    private fun saveManualLocation() {
        val parsed = parseCoordinates(etCoord.text.toString())
        if (parsed == null) {
            toast("Format koordinat salah. Contoh: -7.768287,111.526573")
            return
        }
        val (lat, lon) = parsed

        if (lat !in -90.0..90.0) {
            toast("Latitude harus antara -90 dan 90.")
            return
        }
        if (lon !in -180.0..180.0) {
            toast("Longitude harus antara -180 dan 180.")
            return
        }

        prefs.edit()
            .putString(KEY_LAT, lat.toString())
            .putString(KEY_LON, lon.toString())
            .apply()
        fillInputFromPrefs()
        refreshUi(MockLocationService.running)
        toast(
            if (MockLocationService.running) "Koordinat disimpan dan langsung dipakai."
            else "Koordinat disimpan."
        )
    }

    // --------------------------------------------------- Switch ON / OFF

    private fun tryTurnOn() {
        if (prefs.getString(KEY_LAT, null) == null || prefs.getString(KEY_LON, null) == null) {
            toast("Isi koordinat atau tekan \"Ambil Lokasi Saat Ini\" dulu.")
            setSwitch(false)
            return
        }

        requestLocationThen {
            if (!MockLocationService.isMockAllowed(this)) {
                setSwitch(false)
                showMockSettingDialog()
            } else {
                startForegroundService(Intent(this, MockLocationService::class.java))
                refreshUi(true)
                // Sinkronkan lagi kalau service ternyata gagal start.
                handler.postDelayed({ refreshUi(MockLocationService.running) }, 1500)
            }
        }
    }

    private fun turnOff() {
        stopService(Intent(this, MockLocationService::class.java))
        refreshUi(false)
    }

    private fun showMockSettingDialog() {
        AlertDialog.Builder(this)
            .setTitle("Mock Location belum diaktifkan")
            .setMessage(
                "Aplikasi ini belum dipilih sebagai \"Mock location app\".\n\n" +
                "Buka Opsi Pengembang > Pilih aplikasi lokasi palsu (Select mock location app) " +
                "> pilih Lock.\n\n" +
                "Kalau Opsi Pengembang belum muncul: Pengaturan > Tentang ponsel > " +
                "ketuk Nomor build 7 kali."
            )
            .setPositiveButton("Buka Pengaturan") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                } catch (e: ActivityNotFoundException) {
                    toast("Opsi Pengembang belum aktif di HP ini.")
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ------------------------------------------------------ Tile Quick Settings

    private fun addTile() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val sbm = getSystemService(StatusBarManager::class.java)
            sbm.requestAddTileService(
                ComponentName(this, LockTileService::class.java),
                "Lock",
                Icon.createWithResource(this, R.drawable.ic_lock_small),
                mainExecutor
            ) { _ -> }
        } else {
            toast("Tarik panel atas, ketuk ikon pensil (Edit), lalu seret tile \"Lock\" ke atas.")
        }
    }
}
